# Sổ Tay Vật Lý Sân Khấu, Khai Bút 4 Pha & Đạo Cụ Chuẩn Hóa — Trà Nguội V8.6.1

## 1. Hệ tọa độ sân khấu (`STAGE_VIEWBOX = "62 126 416 250"`) & Khung Giao Diện
- **Trục ngang X**: `62 .. 478`, tâm khung hình tại `X = 270`. Vùng an toàn tuyệt đối trên điện thoại 9:19.5 là `X = 105 .. 435`.
- **Trục dọc Y**:
  - Mặt đất mặc định (`terrain.y`): `352`.
  - Bầu trời (`layer: "sky"` hoặc `atmosphere`): `Y = 140 .. 255`.
  - Với đạo cụ đặt đất (`anchorType: "ground"`, `layer !== "sky"`): `y = 0` chạm đúng mặt đất, số **âm** đi lên trời (`y = -62` là cao hơn mặt đất `62px`).
- **Chuẩn hiển thị Canvas 1080×1920**:
  - Thanh tiêu đề góc trên (`CHÉN XX — TÊN` + chấm đỏ) có `headerLeft = 132px`, `headerWidth = 816px` (`X = 132..948`), lề trái = lề phải = `132px`, đối xứng tâm tuyệt đối với khung Sân khấu (`stageLeft = 132px`, `stageWidth = 816px`).
  - Vạch cọ Đỏ Chu Sa bên trái khối Quote là **1 nét thẳng đồng nhất** (`width: 3.2px`), kéo dài mượt từ trên xuống dưới theo đường cong `Easing.inOut(Easing.sin)`.
  - Mỗi Chén khi kết xuất chỉ xuất **1 file MP4 duy nhất** (`Chén XX - Tên.mp4`).

## 2. Kiến trúc Khai Bút Thư Pháp Chậm Rãi 4 Pha V8.6.1 (`0.00s → 3.80s` · Cosine S-Curve)
Toàn bộ sân khấu mở màn từ trang giấy trắng tinh và được vẽ bằng **1 đường cong Cosine S-Curve duy nhất** (`0.5 - 0.5 * Math.cos(Math.PI * p)`), tuyệt đối không chồng 2 hàm Cubic Ease-Out gây chớp hình:
1. **Pha 1 — Nét cọ chân trời (`0.00s → 2.20s`, 132 frames @ 60fps)**: Đường mặt đất (`terrain`) chạm bút ở lề trái, lướt đều sang phải và nhấc cọ nhẹ ở lề phải.
2. **Pha 2 — Phác nét cọ 3 tầng đạo cụ (Phác viền `0.00 → 0.85`, Loang mực đặc `0.52 → 1.00`)**:
   - **Tầng 1 (`0.40s → 2.25s`, `1.85s`)**: Cảnh xa (`layer: "far" | "sky"`) và ghế ngồi / kiến trúc nền (`std_chair`, `bench`, `office_window_frame`, `gate`, `tree`).
   - **Tầng 2 (`1.15s → 3.10s`, `1.95s`)**: Bàn làm việc & đạo cụ đặt sàn (`std_work_desk`, `small_work_desk`, `low_tea_table`, `boulder`, `warm_house`).
   - **Tầng 3 (`1.95s → 3.80s`, `1.85s`)**: Đạo cụ trên mặt bàn hoặc cầm tay (`desk_calendar`, `small_cup`, `laptop`, `bowl`, `teapot`, `vase`, `lamp`, `clock`, `envelope`, hoặc mọi prop có `y <= -11` / `follow`).
   - Ngay cả các hình mảng đặc (`strokeScale: 0`) cũng tự sinh nét cọ dẫn mảnh (`0.68x`) trong lúc đang vẽ trước khi mực đặc thấm vào.
3. **Pha 3 — Phác nét thư pháp cho Nhân vật (`CloakedTraveler` & `actor.rig`)**:
   - Nhân vật đứng/đi bộ phác nét từ **`0.35s → 2.00s` (`1.65s`)** theo 3 nhịp lệch pha: **Đầu (`0.00 → 0.58`) $\rightarrow$ Áo choàng (`0.12 → 0.80`) $\rightarrow$ Tay & Chân (`0.26 → 0.90`)**, đồng thời mảng mực than loang đầy từ `0.50 → 1.00`.
   - Nhân vật ngồi ghế (`sitProgress >= 0.5`) phác nét từ **`1.20s → 3.05s` (`1.85s`)** để chiếc ghế Tầng 1 đã hiện rõ trước khi vẽ người ngồi.
   - Đạo cụ / nhân vật bước vào muộn (`enterAt` > `0.1s`) tự động phác nét cọ chậm rãi trong **`1.50s – 1.55s`**.
4. **Pha 4 — Thu hồi nét cuối vòng lặp (`T - 1.35s → T`)**: Trong `1.35s` cuối video, toàn bộ `drawProgress` của chân trời, đạo cụ và nhân vật thu hồi mượt về `0` để khép vòng Seamless Loop.

## 3. Khung Xương Nhân Vật 2-Bone IK & Bộ Đạo Cụ Chuẩn Hóa (`scale = 1.0`)
- **Khi đứng / bước đi (`sitProgress = 0`)**:
  - Chân tại `y = 0`, đỉnh đầu tròn tại **`y = -48.2 * scale`** (ở `scale = 1.15`, đỉnh đầu cao tới `-55.4px`).
- **Khi ngồi trên ghế (`pose: "sit_lean"`, `sitProgress = 1`) — Chuẩn 2-Bone IK**:
  - Hông khóa tại `(0, -10.5)` khớp mặt ghế `y = -10.5`; đầu gối tại `(10.5, -10.5)`; bàn chân chạm đất tại `(10.5, 0)`.
  - `leanDeg` chỉ nghiêng phần cột sống trên và cổ, không làm trượt hông hay nhổng chân.
- **Thông số lắp ghép Ghế — Bàn — Đạo cụ mặt bàn**:
  - `std_chair` (alias cũ `stool`): Mặt ghế `y = -10.5`, lưng ghế `x = -4.2, y = -10.5..-25.0`. Đặt cùng tọa độ `x` với nhân vật ngồi (hoặc lệch `-2px`).
  - `small_work_desk` / `std_work_desk`: Mặt bàn `y = -19.2`, chân bàn chạm đất `y = 0`. Đặt cách nhân vật ngồi **`ΔX = +24px .. +28px`**.
  - `low_tea_table`: Mặt bàn trà thấp `y = -14.2`, rộng `32px`.
  - `desk_calendar`: Đã dựng sẵn ở cao độ mặt bàn `-19.2`, nên khi đặt trên `std_work_desk` truyền `y: 0` (hoặc với `small_cup` gốc `y = 0` thì truyền `y: -19.2`).
  - `walking_bill`: Tờ hóa đơn có 2 chân khớp động `swing` (`driveByMotion: true`), dùng `rig: "walking_bill"` trong `actors[]` để bước đi tự nhiên vào sân khấu.
- **Quy tắc chống chạm đầu & chống mảng đen**:
  - Mọi đạo cụ vòm che trên đầu nhân vật đứng phải đặt **gầm dưới cùng cao hơn `y = -61`** (`y = -62 .. -80`).
  - Khi bật `forceSolidStyle: true`, các khung rỗng (cửa sổ, khung lịch, bảng biểu) phải dùng `"fill": "none"`, tránh dùng `"fill": "bg"` đè đen kín lòng đạo cụ.

## 4. Hệ 3 Bảng Màu Signature (`themeId`)
Chỉ sử dụng đúng **3 bảng màu** chuẩn của kênh:
- **`MINIMAL_LIGHT`** (*Giấy Trà Ấm `#F1EAE0`* — chủ đạo ban ngày, hợp `Morning` & `Anytime`, 85% kênh).
- **`MINIMAL_DARK`** (*Khói Trà Chiều `#E4DDD3`* — nền giấy khói xám nâu ấm trầm lắng, dịu mắt chiều muộn/đêm).
- **`WARM_NOIR`** (*Ô Long Cổ `#1B1714`* — nền đêm tối ấm duy nhất, chữ kem ngà `#EDE5D8`, Đỏ Chu Sa `#F06A4E` / `#DF5438`).
*(Hai bảng màu cũ `SLATE_CALM` và `DARK_CONTEMPLATIVE` đã được loại bỏ và tự động ánh xạ về `MINIMAL_LIGHT` / `WARM_NOIR`).*
